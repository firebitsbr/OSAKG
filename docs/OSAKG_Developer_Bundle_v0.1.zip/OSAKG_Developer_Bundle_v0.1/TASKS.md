# TASKS.md — Work queue

- [ ] M0.1 Create Rust workspace and crate boundaries.
- [ ] M0.2 Create Tauri 2 + React + Three.js desktop shell.
- [ ] M0.3 Create typed graph DTOs and sample fixtures.
- [ ] M0.4 Add format/lint/test scripts and CI.
- [ ] M0.5 Implement synthetic org sphere with orbit camera.
- [ ] M1.1 Implement Git snapshot and file inventory.
- [ ] M1.2 Implement Rust/TypeScript parsing adapters.
- [ ] M2.1 Implement evidence SQLite schema.
- [ ] M2.2 Implement graph store adapter.
- [ ] M3.1 Implement explicit cross-repo API/package matching.
- [ ] M4.1 Implement semantic zoom and selection.
- [ ] M5.1 Implement passive security enrichment.
- [ ] M6.1 Implement bounded candidate path engine.

Each task must include tests, docs and reproducible execution report before checking it off.
