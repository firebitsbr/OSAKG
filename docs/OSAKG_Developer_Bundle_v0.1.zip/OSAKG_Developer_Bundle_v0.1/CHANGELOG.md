# Changelog

## 0.1.0 — Specification bundle
- Established OSAKG identity, architecture, agent harness, graph schema, 3D universe design, security model, API contracts, roadmap and tests.
- No application code is included in this bundle.
