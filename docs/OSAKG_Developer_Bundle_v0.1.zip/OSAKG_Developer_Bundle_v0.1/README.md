# OSAKG — Offensive Security Adversarial Knowledge Graph

An authorization-first, evidence-driven, multi-repository knowledge graph for code intelligence, attack-surface discovery, cross-repository dataflow, AI red teaming and interactive 3D exploration.

## Status
Architecture and implementation specification v0.1. This bundle is a **development harness**, not a finished application. All example vulnerabilities, graph paths and metrics are synthetic until validated.

## Development environment
- VS Code with OpenCode and Antigravity extensions.
- Rust stable workspace for API, ingestion, graph fusion, analysis and path reasoning.
- Tauri 2 desktop shell with React/TypeScript + Three.js UI.
- FalkorDB graph storage; SQLite evidence metadata.
- Optional external scanners: Joern, Opengrep, OSV-Scanner, with adapters and version pinning.

## First steps
1. Read `AGENTS.md`, `HARNESS.md`, `SCOPE.md` and `ARCHITECTURE.md`.
2. In OpenCode or Antigravity, use the prompt in `PROMPTS/BOOTSTRAP.md`.
3. Implement milestone M0 before M1. Do not skip tests or fabricate results.
4. Begin with synthetic fixtures; ingest external organizations only after explicit scope approval.

## Core invariant
A graph connection is not proof of exploitability. Every security claim must have provenance, confidence, preconditions and validation state.

## Project map
See `ROADMAP.md`, `GRAPH_SCHEMA.md`, `UNIVERSE_3D.md`, `SECURITY.md`, `TESTING.md`, `AI_REDTEAM.md`, `DATA_SOURCES.md`, `API_CONTRACT.md`, `DECISIONS.md`, `TASKS.md` and `PROMPTS/`.
